css_dir = '.'
sass_dir = 'sass'
relative_assets = true

#output_style = :compact
#line_comments = true

preferred_syntax = :scss
